<!DOCTYPE html>
	<html lang="en-US">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Check Your Glasses &#8212; WordPress</title>
	<meta name='robots' content='noindex, follow' />
<!--n2css--><link rel='stylesheet' id='dashicons-css' href='https://checkyourglasses.com/wp-includes/css/dashicons.min.css?ver=6.5.15' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://checkyourglasses.com/wp-includes/css/buttons.min.css?ver=6.5.15' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css' href='https://checkyourglasses.com/wp-admin/css/forms.min.css?ver=6.5.15' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://checkyourglasses.com/wp-admin/css/l10n.min.css?ver=6.5.15' type='text/css' media='all' />
<link rel='stylesheet' id='login-css' href='https://checkyourglasses.com/wp-admin/css/login.min.css?ver=6.5.15' type='text/css' media='all' />
<link rel='stylesheet' id='wsl-widget-css' href='https://checkyourglasses.com/wp-content/plugins/wordpress-social-login/assets/css/style.css?ver=6.5.15' type='text/css' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="https://checkyourglasses.com/wp-content/uploads/2021/09/cropped-Cil-cruce-2-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://checkyourglasses.com/wp-content/uploads/2021/09/cropped-Cil-cruce-2-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://checkyourglasses.com/wp-content/uploads/2021/09/cropped-Cil-cruce-2-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://checkyourglasses.com/wp-content/uploads/2021/09/cropped-Cil-cruce-2-270x270.jpg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
/* <![CDATA[ */
document.body.className = document.body.className.replace('no-js','js');
/* ]]> */
</script>

		<div id="login">
		<h1><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://checkyourglasses.com/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
			
<!--
	wsl_render_auth_widget
	WordPress Social Login 2.3.3.
	http://wordpress.org/plugins/wordpress-social-login/
-->

<style type="text/css">
.wp-social-login-connect-with{}.wp-social-login-provider-list{}.wp-social-login-provider-list a{}.wp-social-login-provider-list img{}.wsl_connect_with_provider{}</style>

<div class="wp-social-login-widget">

	<div class="wp-social-login-connect-with">Connect with:</div>

	<div class="wp-social-login-provider-list">

		<a rel="nofollow" href="https://checkyourglasses.com/wp-login.php?action=wordpress_social_authenticate&#038;mode=login&#038;provider=Facebook&#038;redirect_to=https%3A%2F%2Fcheckyourglasses.com%2Fwp-login.php" title="Connect with Facebook" class="wp-social-login-provider wp-social-login-provider-facebook" data-provider="Facebook">
			<img alt="Facebook" title="Connect with Facebook" src="https://checkyourglasses.com/wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom//facebook.png" />
		</a>

		<a rel="nofollow" href="https://checkyourglasses.com/wp-login.php?action=wordpress_social_authenticate&#038;mode=login&#038;provider=Google&#038;redirect_to=https%3A%2F%2Fcheckyourglasses.com%2Fwp-login.php" title="Connect with Google" class="wp-social-login-provider wp-social-login-provider-google" data-provider="Google">
			<img alt="Google" title="Connect with Google" src="https://checkyourglasses.com/wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom//google.png" />
		</a>

		<a rel="nofollow" href="https://checkyourglasses.com/wp-login.php?action=wordpress_social_authenticate&#038;mode=login&#038;provider=Twitter&#038;redirect_to=https%3A%2F%2Fcheckyourglasses.com%2Fwp-login.php" title="Connect with Twitter" class="wp-social-login-provider wp-social-login-provider-twitter" data-provider="Twitter">
			<img alt="Twitter" title="Connect with Twitter" src="https://checkyourglasses.com/wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom//twitter.png" />
		</a>

	</div>

	<div class="wp-social-login-widget-clearing"></div>

</div>

<!-- wsl_render_auth_widget -->

			<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://checkyourglasses.com/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a rel="nofollow" class="wp-login-register" href="https://checkyourglasses.com/wp-login.php?action=register">Register</a> | <a class="wp-login-lost-password" href="https://checkyourglasses.com/wp-login.php?action=lostpassword">Lost your password?</a>			</p>
			<script type="text/javascript">
/* <![CDATA[ */
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
/* ]]> */
</script>
		<p id="backtoblog">
			<a href="https://checkyourglasses.com/">&larr; Go to Check Your Glasses</a>		</p>
			</div>
			<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="zxcvbn-async-js-extra">
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/checkyourglasses.com\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-extra">
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-admin/js/password-strength-meter.min.js?ver=6.5.15" id="password-strength-meter-js"></script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-includes/js/wp-util.min.js?ver=6.5.15" id="wp-util-js"></script>
<script type="text/javascript" id="user-profile-js-extra">
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"6de7186a48"};
/* ]]> */
</script>
<script type="text/javascript" src="https://checkyourglasses.com/wp-admin/js/user-profile.min.js?ver=6.5.15" id="user-profile-js"></script>
	<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092" integrity="sha512-UKNk8GbxkABxKcXYuLkO16EleLGUkcvJWtpSNmExE0Too3ZaFAxTscNWEc1OdAv5/BikHawapSCaiD2XCmp+Bw==" data-cf-beacon='{"version":"2024.11.0","token":"9c960d71a9c647c393810fca24b8ba0b","r":1,"spa":2}' crossorigin="anonymous"></script>
</body>
	</html>
	<!-- wp-login.php -->